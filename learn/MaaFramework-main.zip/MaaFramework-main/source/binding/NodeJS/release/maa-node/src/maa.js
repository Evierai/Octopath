module.exports = globalThis.MaaAPI
