#include <iostream>

import maa.core;

int main()
{
    std::cout << MaaVersion();
}
