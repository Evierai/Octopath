# MaaFW Python binding

## Install

```bash
python -m pip install maafw
```
