#pragma once

#include "Utils/SafeWindows.hpp"

#include <d3d11.h>
#include <dxgi1_2.h>
