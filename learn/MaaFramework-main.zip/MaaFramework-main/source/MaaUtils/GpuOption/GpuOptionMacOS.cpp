#ifdef __APPLE__

#include "Utils/GpuOption.h"

MAA_NS_BEGIN

std::optional<int> perfer_gpu()
{
    // TODO
    return std::nullopt;
}

MAA_NS_END

#endif // __APPLE__
