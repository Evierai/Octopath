#pragma once

#include "Conf/Conf.h"

MAA_SUPPRESS_CV_WARNINGS_BEGIN
#include <opencv2/core/mat.hpp>
MAA_SUPPRESS_CV_WARNINGS_END
