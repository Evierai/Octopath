#pragma once

#include <optional>

#include "Conf/Conf.h"
#include "MaaFramework/MaaPort.h"

MAA_NS_BEGIN

MAA_UTILS_API std::optional<int> perfer_gpu();

MAA_NS_END
