#pragma once

#include <string>

#include "Conf/Conf.h"
#include "MaaFramework/MaaPort.h"

MAA_NS_BEGIN

MAA_UTILS_API std::string make_uuid();

MAA_NS_END
