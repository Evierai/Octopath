#if defined(__linux__)

#include "AdbDeviceLinuxFinder.h"

MAA_TOOLKIT_NS_BEGIN

MAA_TOOLKIT_NS_END

#endif
