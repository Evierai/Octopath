#pragma once

#include "MaaFramework/MaaDef.h" // IWYU pragma: export
