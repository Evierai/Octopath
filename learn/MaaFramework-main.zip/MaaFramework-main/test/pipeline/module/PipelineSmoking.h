#pragma once

#include <filesystem>

bool pipeline_smoking(const std::filesystem::path& testset_dir);
