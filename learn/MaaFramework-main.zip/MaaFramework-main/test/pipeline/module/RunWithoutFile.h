#pragma once

#include <filesystem>

bool run_without_file(const std::filesystem::path& testset_dir);
