import './inject-server.js'

export * from '../../source/binding/NodeJS/release/maa-node/dist/index-server'
