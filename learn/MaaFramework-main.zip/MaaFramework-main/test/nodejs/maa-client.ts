import './inject-client'

export * from '../../source/binding/NodeJS/release/maa-node/dist/index-client'
