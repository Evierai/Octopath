#include <iostream>

import maa.core;
import maa.toolkit;
import maa.agent.client;

int main()
{
    std::cout << MaaVersion();
}
