import maa from "../../source/binding/NodeJS/release/maa-node/dist/index-server";
// import maa from '@maaxyz/maa-node/server'

console.log(maa.Global.version);
